package Controllers;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import Services.LoginService;

//import org.springframework.stereotype.Controller;
 
@Controller
public class IndexController {

	@Autowired
    private LoginService loginService;
	
	@RequestMapping("/")
	public String display()  
    {  
		System.out.println("Heybaby");
        return "LoginPage";  
    }
	@RequestMapping(value = "/{mailid}", method = RequestMethod.GET)
	 public ModelAndView markAsRead(@PathVariable("mailid") String mailid,@RequestParam("code")String verification,HttpServletRequest request,HttpServletResponse response, HttpSession session)  
    {
            System.out.println("email : "+mailid);
            System.out.println("Verification code : "+verification);
            String Confirmed = loginService.confirmuser(mailid,verification);
            ModelAndView mv = new ModelAndView();
           
        if(Confirmed.equals("valid"))
           {
        	System.out.println("Succesfully Verified");
        	mv.setViewName("LoginPage");
           }
        else if(Confirmed.equals("invalid"))
        {
        	mv.setViewName("ConfirmationPage");
        	System.out.println("UnSuccesfully Verified");
        }
        else
        {
        	System.out.println("Error");
        	mv.setViewName("demo");
        }
            	
            
			return mv;
	  }
}
